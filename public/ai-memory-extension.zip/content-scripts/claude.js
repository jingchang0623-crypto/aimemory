var claude=(function(){var e=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function t(e){return e}var n={gemini:`rich-textarea .ql-editor, rich-textarea [contenteditable]`,kimi:`[data-lexical-editor="true"]`,chatgpt:`#prompt-textarea.ProseMirror, #prompt-textarea[contenteditable]`,claude:`.ProseMirror[contenteditable], [contenteditable].ProseMirror`};function r(e){return e.closest?.(`rich-textarea`)||e.classList.contains(`ql-editor`)?`gemini`:e.getAttribute(`data-lexical-editor`)===`true`?`kimi`:e.id===`prompt-textarea`||e.closest?.(`#prompt-textarea`)?`chatgpt`:e.classList.contains(`ProseMirror`)&&e.getAttribute(`contenteditable`)===`true`&&e.id!==`prompt-textarea`?`claude`:`unknown`}function i(e){if(e&&e!==`unknown`){let t=n[e];if(t)return document.querySelector(t)}for(let[,e]of Object.entries(n)){let t=document.querySelector(e);if(t)return t}return null}function a(e,t){let n=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,`value`);n?.set?n.set.call(e,t):e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}function o(e){let t=[new InputEvent(`input`,{bubbles:!0,cancelable:!0,inputType:`insertText`}),new Event(`change`,{bubbles:!0}),new Event(`blur`,{bubbles:!0}),new Event(`focus`,{bubbles:!0})];for(let n of t)try{e.dispatchEvent(n)}catch{}}function s(e,t,n){try{let r=p(t).replace(/\n/g,`<br>`);if(n)e.innerHTML=`<p>${r}</p>`;else{let t=document.createElement(`p`);t.innerHTML=r,e.appendChild(t)}return o(e),m(e),!0}catch(e){return console.warn(`[aimem] setContentEditableContent failed:`,e),!1}}function c(e,t){try{return e.focus(),document.execCommand(`insertText`,!1,t)?(o(e),!0):!1}catch(e){return console.warn(`[aimem] execCommandInsert failed:`,e),!1}}function l(e,t,n){try{let r=e.closest?.(`rich-textarea`)?.__quill??e.__quill;if(r){if(n)r.setText(t);else{let e=r.getLength();r.insertText(e-1,`
`+t)}return o(e),!0}}catch(e){console.warn(`[aimem] Gemini Quill injection failed:`,e)}return!1}function u(e,t,n){try{let r=e.__lexicalEditor;if(r?.update)return r.update(()=>{let e=r.getRootElement?.();if(e){n&&(e.innerHTML=``);let r=document.createElement(`p`);r.textContent=t,e.appendChild(r)}}),o(e),!0}catch(e){console.warn(`[aimem] Kimi Lexical injection failed:`,e)}return!1}function d(e,t,n){return s(e,t,n)}function f(e,t,n={}){let{dispatchEvents:i=!0,focusFirst:f=!0,clearFirst:p=!1}=n;if(!e||!t)return console.warn(`[aimem] injectMemory: missing element or text`),!1;try{switch(f&&e.focus(),r(e)){case`gemini`:if(l(e,t,p))return!0;break;case`kimi`:if(u(e,t,p))return!0;break;case`chatgpt`:case`claude`:if(d(e,t,p))return!0;break}if(e.getAttribute(`contenteditable`)===`true`&&s(e,t,p))return!0;if(e instanceof HTMLTextAreaElement)return a(e,p?t:e.value+t),i&&o(e),!0;if(e instanceof HTMLInputElement){let n=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`);return n?.set?n.set.call(e,p?t:e.value+t):e.value=p?t:e.value+t,i&&o(e),!0}return c(e,t)?!0:(console.warn(`[aimem] All injection strategies failed for element:`,e),!1)}catch(e){return console.error(`[aimem] injectMemory error:`,e),!1}}function p(e){let t=document.createElement(`div`);return t.textContent=e,t.innerHTML}function m(e){try{let t=document.createRange();t.selectNodeContents(e),t.collapse(!1);let n=window.getSelection();n&&(n.removeAllRanges(),n.addRange(t))}catch{}}function h(){e.runtime.onMessage.addListener((e,t,n)=>{if(e?.type===`INJECT_MEMORY_TO_INPUT`)return g(e.content).then(n).catch(e=>{n({success:!1,error:e instanceof Error?e.message:`Injection failed`})}),!0})}async function g(e){if(!e)return{success:!1,error:`No content provided`};let t=i();return t?f(t,e,{dispatchEvents:!0,focusFirst:!0,clearFirst:!1})?(console.log(`[AI Memory] Successfully injected memory into input`),{success:!0}):{success:!1,error:`Failed to inject into input element. The input format may not be supported.`}:{success:!1,error:`No chat input found. Make sure you have a chat page open with an input box.`}}var _=`
(function() {
  if (window.__aiMemoryClaudeIntercepted) return;
  window.__aiMemoryClaudeIntercepted = true;

  const originalFetch = window.fetch;
  const pendingConversations = new Map();

  window.fetch = async function(...args) {
    const response = await originalFetch.apply(this, args);

    try {
      const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';

      // Intercept completion responses (SSE stream)
      if (url.includes('/completion')) {
        const cloned = response.clone();
        // Extract conversation ID from URL
        const convMatch = url.match(/chat_conversations\\/([a-f0-9-]+)/);
        const conversationId = convMatch?.[1];

        cloned.text().then(text => {
          const messages = [];
          const lines = text.split('\\n');
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const json = JSON.parse(line.slice(6));
                if (json.completion) {
                  messages.push({
                    role: 'assistant',
                    content: json.completion,
                    stop_reason: json.stop_reason,
                  });
                }
                if (json.error) {
                  console.warn('[AI Memory] Claude completion error:', json.error);
                }
              } catch (e) {}
            }
          }

          if (messages.length > 0 && conversationId) {
            window.postMessage({
              type: 'AIMEMORY_CLAUDE_COMPLETION',
              source: 'ai-memory-extension',
              data: {
                conversationId,
                messages,
                url: window.location.href,
              }
            }, '*');
          }
        }).catch(() => {});
      }

      // Intercept conversation creation
      if (url.includes('/chat_conversations') && !url.includes('/completion') && args[1]?.method === 'POST') {
        const cloned = response.clone();
        cloned.json().then(data => {
          if (data?.uuid) {
            window.postMessage({
              type: 'AIMEMORY_CLAUDE_NEW_CONVERSATION',
              source: 'ai-memory-extension',
              data: {
                conversationId: data.uuid,
                name: data.name || '',
                url: window.location.href,
              }
            }, '*');
          }
        }).catch(() => {});
      }

      // Intercept conversation list
      if (url.includes('/chat_conversations') && !url.includes('/completion') && (!args[1]?.method || args[1].method === 'GET')) {
        const cloned = response.clone();
        cloned.json().then(data => {
          if (Array.isArray(data)) {
            window.postMessage({
              type: 'AIMEMORY_CLAUDE_CONVERSATIONS_LIST',
              source: 'ai-memory-extension',
              data: {
                conversations: data.map(c => ({
                  id: c.uuid,
                  name: c.name,
                  created_at: c.created_at,
                  updated_at: c.updated_at,
                })),
              }
            }, '*');
          }
        }).catch(() => {});
      }
    } catch (e) {
      // Silently ignore interception errors
    }

    return response;
  };

  // DOM scraping fallback - capture conversation from rendered page
  function captureFromDOM() {
    try {
      const urlMatch = window.location.pathname.match(/\\/chat\\/([a-f0-9-]+)/);
      if (!urlMatch) return;
      const conversationId = urlMatch[1];

      // Get conversation title
      const titleEl = document.querySelector('h1') ||
                      document.querySelector('[data-testid="conversation-title"]') ||
                      document.querySelector('.font-claude-message');
      const title = titleEl?.textContent?.trim() || '';

      // Get all message turns - Claude uses specific data attributes and classes
      const turnEls = document.querySelectorAll('[data-testid^="turn-"]') ||
                       document.querySelectorAll('.group\\/conversation-turn');
      const messages = [];

      for (const turnEl of turnEls) {
        // Determine role from data attribute or class
        const isHuman = turnEl.querySelector('[data-testid="human-turn"]') ||
                        turnEl.classList.contains('human') ||
                        turnEl.querySelector('.human-message');
        const role = isHuman ? 'user' : 'assistant';

        // Get message content
        const contentEl = turnEl.querySelector('.font-claude-message') ||
                          turnEl.querySelector('[data-testid="message-content"]') ||
                          turnEl.querySelector('.markdown') ||
                          turnEl.querySelector('p');
        const content = contentEl?.textContent?.trim() || '';
        if (content) {
          messages.push({ role, content });
        }
      }

      if (messages.length > 0) {
        window.postMessage({
          type: 'AIMEMORY_CLAUDE_DOM_CAPTURE',
          source: 'ai-memory-extension',
          data: {
            conversationId,
            title,
            messages,
            url: window.location.href,
          }
        }, '*');
      }
    } catch (e) {}
  }

  // Capture on load and periodically
  setTimeout(captureFromDOM, 3000);
  setInterval(captureFromDOM, 30000);

  // Also observe DOM changes for real-time capture
  const observer = new MutationObserver((mutations) => {
    // Check if new messages were added
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType === Node.ELEMENT_NODE) {
          const el = node;
          if (el.querySelector?.('[data-testid^="turn-"]') ||
              el.querySelector?.('.group\\/conversation-turn')) {
            // New turn added, schedule a capture
            setTimeout(captureFromDOM, 1000);
            return;
          }
        }
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();
`,v=t({matches:[`https://claude.ai/*`],runAt:`document_start`,allFrames:!1,main(e){console.log(`[AI Memory] Claude content script loaded`),h();let t=document.createElement(`script`);t.textContent=_,t.dataset.aiMemory=`claude-interceptor`,(document.head||document.documentElement).appendChild(t),t.remove();let n=new Map,r=new Map;function i(e){let t=r.get(e);return t&&Date.now()-t<6e4?!1:(r.set(e,Date.now()),!0)}window.addEventListener(`message`,e=>{if(e.data?.source===`ai-memory-extension`)try{let{type:t,data:r}=e.data;if(t===`AIMEMORY_CLAUDE_COMPLETION`){let{conversationId:e,messages:t}=r,a=n.get(e)||{title:``,messages:[],lastCapture:0};for(let e of t)e.content.trim()&&a.messages.push({role:`assistant`,content:e.content});a.lastCapture=Date.now(),n.set(e,a),y(e,a),setTimeout(()=>{a.messages.length>0&&i(e)&&x(e,a.title||b()||`Claude Conversation ${new Date().toLocaleString()}`,a.messages)},2e3)}if(t===`AIMEMORY_CLAUDE_DOM_CAPTURE`){let{conversationId:e,title:t,messages:n}=r;e&&i(e)&&x(e,t,n)}}catch(e){console.error(`[AI Memory] Error processing Claude message:`,e)}})}});function y(e,t){let n=document.querySelectorAll(`[data-testid^="turn-"]`),r=n[n.length-1];if(r&&r.querySelector(`[data-testid="human-turn"]`)){let e=(r.querySelector(`.font-claude-message`)||r.querySelector(`p`))?.textContent?.trim();e&&!t.messages.find(t=>t.role===`user`&&t.content===e)&&t.messages.unshift({role:`user`,content:e})}}function b(){let e=document.querySelector(`h1`);return e?.textContent?e.textContent.trim():``}function x(t,n,r){e.runtime.sendMessage({type:`CONVERSATION_CAPTURED`,platform:`claude`,data:{conversationId:t,title:n,messages:r,url:window.location.href}}).catch(e=>{console.warn(`[AI Memory] Could not send to background:`,e)})}var S={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},C=class e extends Event{static EVENT_NAME=w(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function w(t){return`${e?.runtime?.id}:claude:${t}`}var T=typeof globalThis.navigation?.addEventListener==`function`;function E(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),T?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new C(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new C(e,t)),t=e)},1e3))}}}var D=class t{static SCRIPT_STARTED_MESSAGE_TYPE=w(`wxt:content-script-started`);id;abortController;locationWatcher=E(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return e.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?w(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),S.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(t.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),window.postMessage({type:t.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let e=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(t.SCRIPT_STARTED_MESSAGE_TYPE,e),this.onInvalidated(()=>document.removeEventListener(t.SCRIPT_STARTED_MESSAGE_TYPE,e))}},O={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=v;return await e(new D(`claude`,t))}catch(e){throw O.error(`The content script "claude" crashed on startup!`,e),e}})()})();
claude;