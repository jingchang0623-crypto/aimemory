var chatgpt=(function(){var e=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function t(e){return e}var n={gemini:`rich-textarea .ql-editor, rich-textarea [contenteditable]`,kimi:`[data-lexical-editor="true"]`,chatgpt:`#prompt-textarea.ProseMirror, #prompt-textarea[contenteditable]`,claude:`.ProseMirror[contenteditable], [contenteditable].ProseMirror`};function r(e){return e.closest?.(`rich-textarea`)||e.classList.contains(`ql-editor`)?`gemini`:e.getAttribute(`data-lexical-editor`)===`true`?`kimi`:e.id===`prompt-textarea`||e.closest?.(`#prompt-textarea`)?`chatgpt`:e.classList.contains(`ProseMirror`)&&e.getAttribute(`contenteditable`)===`true`&&e.id!==`prompt-textarea`?`claude`:`unknown`}function i(e){if(e&&e!==`unknown`){let t=n[e];if(t)return document.querySelector(t)}for(let[,e]of Object.entries(n)){let t=document.querySelector(e);if(t)return t}return null}function a(e,t){let n=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,`value`);n?.set?n.set.call(e,t):e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}function o(e){let t=[new InputEvent(`input`,{bubbles:!0,cancelable:!0,inputType:`insertText`}),new Event(`change`,{bubbles:!0}),new Event(`blur`,{bubbles:!0}),new Event(`focus`,{bubbles:!0})];for(let n of t)try{e.dispatchEvent(n)}catch{}}function s(e,t,n){try{let r=p(t).replace(/\n/g,`<br>`);if(n)e.innerHTML=`<p>${r}</p>`;else{let t=document.createElement(`p`);t.innerHTML=r,e.appendChild(t)}return o(e),m(e),!0}catch(e){return console.warn(`[aimem] setContentEditableContent failed:`,e),!1}}function c(e,t){try{return e.focus(),document.execCommand(`insertText`,!1,t)?(o(e),!0):!1}catch(e){return console.warn(`[aimem] execCommandInsert failed:`,e),!1}}function l(e,t,n){try{let r=e.closest?.(`rich-textarea`)?.__quill??e.__quill;if(r){if(n)r.setText(t);else{let e=r.getLength();r.insertText(e-1,`
`+t)}return o(e),!0}}catch(e){console.warn(`[aimem] Gemini Quill injection failed:`,e)}return!1}function u(e,t,n){try{let r=e.__lexicalEditor;if(r?.update)return r.update(()=>{let e=r.getRootElement?.();if(e){n&&(e.innerHTML=``);let r=document.createElement(`p`);r.textContent=t,e.appendChild(r)}}),o(e),!0}catch(e){console.warn(`[aimem] Kimi Lexical injection failed:`,e)}return!1}function d(e,t,n){return s(e,t,n)}function f(e,t,n={}){let{dispatchEvents:i=!0,focusFirst:f=!0,clearFirst:p=!1}=n;if(!e||!t)return console.warn(`[aimem] injectMemory: missing element or text`),!1;try{switch(f&&e.focus(),r(e)){case`gemini`:if(l(e,t,p))return!0;break;case`kimi`:if(u(e,t,p))return!0;break;case`chatgpt`:case`claude`:if(d(e,t,p))return!0;break}if(e.getAttribute(`contenteditable`)===`true`&&s(e,t,p))return!0;if(e instanceof HTMLTextAreaElement)return a(e,p?t:e.value+t),i&&o(e),!0;if(e instanceof HTMLInputElement){let n=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`);return n?.set?n.set.call(e,p?t:e.value+t):e.value=p?t:e.value+t,i&&o(e),!0}return c(e,t)?!0:(console.warn(`[aimem] All injection strategies failed for element:`,e),!1)}catch(e){return console.error(`[aimem] injectMemory error:`,e),!1}}function p(e){let t=document.createElement(`div`);return t.textContent=e,t.innerHTML}function m(e){try{let t=document.createRange();t.selectNodeContents(e),t.collapse(!1);let n=window.getSelection();n&&(n.removeAllRanges(),n.addRange(t))}catch{}}function h(){e.runtime.onMessage.addListener((e,t,n)=>{if(e?.type===`INJECT_MEMORY_TO_INPUT`)return g(e.content).then(n).catch(e=>{n({success:!1,error:e instanceof Error?e.message:`Injection failed`})}),!0})}async function g(e){if(!e)return{success:!1,error:`No content provided`};let t=i();return t?f(t,e,{dispatchEvents:!0,focusFirst:!0,clearFirst:!1})?(console.log(`[AI Memory] Successfully injected memory into input`),{success:!0}):{success:!1,error:`Failed to inject into input element. The input format may not be supported.`}:{success:!1,error:`No chat input found. Make sure you have a chat page open with an input box.`}}var _=`
(function() {
  if (window.__aiMemoryChatGPTIntercepted) return;
  window.__aiMemoryChatGPTIntercepted = true;

  const originalFetch = window.fetch;

  window.fetch = async function(...args) {
    const response = await originalFetch.apply(this, args);

    try {
      const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || '';

      // Intercept conversation text mapping endpoint (contains full conversation)
      if (url.includes('/backend-api/conversation/') && url.includes('/text')) {
        const cloned = response.clone();
        cloned.json().then(data => {
          window.postMessage({
            type: 'AIMEMORY_CHATGPT_CONVERSATION',
            source: 'ai-memory-extension',
            data: {
              endpoint: 'conversation_text',
              url: url,
              payload: data,
              pageUrl: window.location.href,
            }
          }, '*');
        }).catch(() => {});
      }

      // Intercept the conversation feedback/update endpoint
      if (url.includes('/backend-api/conversation') && !url.includes('/conversations') && args[1]?.method === 'POST') {
        const cloned = response.clone();
        // For POST requests, capture the request body too
        let requestBody = null;
        try {
          if (args[1]?.body) {
            requestBody = typeof args[1].body === 'string' ? JSON.parse(args[1].body) : null;
          }
        } catch (e) {}

        cloned.text().then(text => {
          // Parse SSE stream response
          const messages = [];
          const lines = text.split('\\n');
          for (const line of lines) {
            if (line.startsWith('data: ') && line !== 'data: [DONE]') {
              try {
                const json = JSON.parse(line.slice(6));
                if (json.message) {
                  messages.push(json.message);
                }
              } catch (e) {}
            }
          }

          if (messages.length > 0) {
            window.postMessage({
              type: 'AIMEMORY_CHATGPT_CONVERSATION',
              source: 'ai-memory-extension',
              data: {
                endpoint: 'conversation_post',
                url: window.location.href,
                messages: messages,
                requestBody: requestBody,
              }
            }, '*');
          }
        }).catch(() => {});
      }

      // Intercept conversations list endpoint
      if (url.includes('/backend-api/conversations') && !url.includes('/conversation/')) {
        const cloned = response.clone();
        cloned.json().then(data => {
          window.postMessage({
            type: 'AIMEMORY_CHATGPT_CONVERSATIONS_LIST',
            source: 'ai-memory-extension',
            data: {
              endpoint: 'conversations_list',
              conversations: data?.items || [],
            }
          }, '*');
        }).catch(() => {});
      }

      // Intercept ChatGPT memories endpoint
      if (url.includes('/backend-api/memories') && !url.includes('/backend-api/memories/')) {
        const cloned = response.clone();
        cloned.json().then(data => {
          // ChatGPT memories API returns { items: [...] } or { memories: [...] }
          const items = data?.items || data?.memories || (Array.isArray(data) ? data : []);
          if (items.length > 0) {
            window.postMessage({
              type: 'AIMEMORY_CHATGPT_MEMORIES',
              source: 'ai-memory-extension',
              data: {
                endpoint: 'memories_list',
                memories: items.map(item => ({
                  id: item.id || item.uuid || ('mem-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8)),
                  content: item.content || item.text || item.body || '',
                  category: item.category || item.type || undefined,
                  created_at: item.created_at || item.createdAt || item.timestamp || undefined,
                  updated_at: item.updated_at || item.updatedAt || undefined,
                })),
              }
            }, '*');
          }
        }).catch(() => {});
      }

      // Also intercept POST/DELETE to /backend-api/memories (new/deleted memory)
      if (url.includes('/backend-api/memories') && args[1]?.method) {
        const method = args[1].method.toUpperCase();
        if (method === 'POST' || method === 'PUT' || method === 'PATCH' || method === 'DELETE') {
          const cloned = response.clone();
          cloned.json().then(data => {
            if (data && (data.content || data.text || data.id)) {
              window.postMessage({
                type: 'AIMEMORY_CHATGPT_MEMORIES',
                source: 'ai-memory-extension',
                data: {
                  endpoint: 'memory_mutation',
                  memory: {
                    id: data.id || data.uuid || ('mem-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8)),
                    content: data.content || data.text || data.body || '',
                    category: data.category || data.type || undefined,
                    created_at: data.created_at || data.createdAt || undefined,
                    updated_at: data.updated_at || data.updatedAt || undefined,
                  },
                  method: method,
                }
              }, '*');
            }
          }).catch(() => {});
        }
      }
    } catch (e) {
      // Silently ignore interception errors
    }

    return response;
  };

  // Also try to capture conversation from the page's __NEXT_DATA__ or React state
  function captureFromDOM() {
    try {
      // ChatGPT stores conversation data in script tags or React fiber
      const conversationId = window.location.pathname.match(/\\/c\\/([a-f0-9-]+)/)?.[1];
      if (!conversationId) return;

      // Try to find conversation title from the page
      const titleEl = document.querySelector('title');
      const title = titleEl?.textContent || 'Untitled Conversation';

      // Get all message elements
      const messageEls = document.querySelectorAll('[data-message-author-role]');
      const messages = [];

      for (const el of messageEls) {
        const role = el.getAttribute('data-message-author-role');
        const contentEl = el.querySelector('.markdown') || el.querySelector('.whitespace-pre-wrap') || el;
        const content = contentEl?.textContent?.trim() || '';
        if (content && role) {
          messages.push({ role, content });
        }
      }

      if (messages.length > 0) {
        window.postMessage({
          type: 'AIMEMORY_CHATGPT_DOM_CAPTURE',
          source: 'ai-memory-extension',
          data: {
            conversationId,
            title,
            messages,
            url: window.location.href,
          }
        }, '*');
      }
    } catch (e) {}
  }

  // Capture on page load and periodically
  setTimeout(captureFromDOM, 3000);
  setInterval(captureFromDOM, 30000);
})();
`,v=t({matches:[`https://chat.openai.com/*`,`https://chatgpt.com/*`],runAt:`document_start`,allFrames:!1,main(e){console.log(`[AI Memory] ChatGPT content script loaded`),h();let t=document.createElement(`script`);t.textContent=_,t.dataset.aiMemory=`chatgpt-interceptor`,(document.head||document.documentElement).appendChild(t),t.remove();let n=new Map,r=6e4;function i(e){let t=n.get(e);if(t&&Date.now()-t<r)return!1;if(n.set(e,Date.now()),n.size>100)for(let[e,t]of n)Date.now()-t>r&&n.delete(e);return!0}window.addEventListener(`message`,e=>{if(e.data?.source===`ai-memory-extension`)try{if(e.data.type===`AIMEMORY_CHATGPT_CONVERSATION`){let{data:t}=e.data,n=y(t.url)||y(t.pageUrl);if(!n||!i(n))return;let r=[];t.endpoint===`conversation_text`?r=x(t.payload):t.endpoint===`conversation_post`&&(r=t.messages.map(e=>({role:e.author?.role||`assistant`,content:e.content?.parts?.join(`
`)||e.content?.text||``}))),r.length>0&&S(n,b()||`ChatGPT Conversation ${new Date().toLocaleString()}`,r)}if(e.data.type===`AIMEMORY_CHATGPT_DOM_CAPTURE`){let{data:t}=e.data;t.conversationId&&i(t.conversationId)&&S(t.conversationId,t.title,t.messages)}if(e.data.type===`AIMEMORY_CHATGPT_MEMORIES`){let{data:t}=e.data;console.log(`[AI Memory] Captured ChatGPT memories:`,t.endpoint),t.endpoint===`memories_list`?C(t.memories):t.endpoint===`memory_mutation`&&t.method!==`DELETE`&&C([t.memory])}}catch(e){console.error(`[AI Memory] Error processing message:`,e)}})}});function y(e){return e?.match(/\/c\/([a-f0-9-]+)/)?.[1]||null}function b(){let e=document.querySelector(`title`);if(e?.textContent&&e.textContent!==`ChatGPT`)return e.textContent.replace(` | ChatGPT`,``).trim();let t=document.querySelector(`nav a[aria-current="page"]`);return t?.textContent?t.textContent.trim():``}function x(e){let t=[];if(!e)return t;if(Array.isArray(e))for(let n of e)n.role&&n.content&&t.push({role:n.role,content:n.content});else if(e.mapping){let n=Object.values(e.mapping);n.sort((e,t)=>(e.create_time||0)-(t.create_time||0));for(let e of n)e.message?.content?.parts&&t.push({role:e.message.author?.role||`unknown`,content:e.message.content.parts.join(`
`)})}return t.filter(e=>e.content.trim().length>0)}function S(t,n,r){e.runtime.sendMessage({type:`CONVERSATION_CAPTURED`,platform:`chatgpt`,data:{conversationId:t,title:n,messages:r,url:window.location.href}}).catch(e=>{console.warn(`[AI Memory] Could not send to background:`,e)})}function C(t){e.runtime.sendMessage({type:`MEMORY_CAPTURED`,platform:`chatgpt`,data:{memories:t}}).catch(e=>{console.warn(`[AI Memory] Could not send memories to background:`,e)})}var w={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},T=class e extends Event{static EVENT_NAME=E(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function E(t){return`${e?.runtime?.id}:chatgpt:${t}`}var D=typeof globalThis.navigation?.addEventListener==`function`;function O(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),D?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new T(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new T(e,t)),t=e)},1e3))}}}var k=class t{static SCRIPT_STARTED_MESSAGE_TYPE=E(`wxt:content-script-started`);id;abortController;locationWatcher=O(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return e.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?E(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),w.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(t.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),window.postMessage({type:t.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let e=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(t.SCRIPT_STARTED_MESSAGE_TYPE,e),this.onInvalidated(()=>document.removeEventListener(t.SCRIPT_STARTED_MESSAGE_TYPE,e))}},A={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=v;return await e(new k(`chatgpt`,t))}catch(e){throw A.error(`The content script "chatgpt" crashed on startup!`,e),e}})()})();
chatgpt;